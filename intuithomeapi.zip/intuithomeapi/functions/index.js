'use strict';

const { dialogflow } = require('actions-on-google');
const functions = require('firebase-functions');
const app = dialogflow();

var answer = '';
const NAME_ACTION = 'askform';

// function responseHandler(app) {
//   // grab the `ledState` value from the Assistant request
//   const formType = app.getArgument('$formType');
//   // parse the user's request text and respond accordingly
//   handleUserRequest(ledState)
//     // let the assistant respond
//     .then(response => app.tell(response))
//     // set the error message
//     .catch(err => console.log(err));
// }
//
// function handleUserRequest (formType) {
//   return new Promise((resolve, reject) => {
//     if (!formType) {
//       return resolve("I don't understand");
//     }
//     if (formType === '1040') {
//       answer = 'Form 1040 (officially, the "U.S. Individual Income Tax Return") is one of three IRS Tax forms used for personal (individual) federal income tax filed with internal revenue service';
//     } else if (formType === '1099') {
//       answer = 'Form 1099 is one of several IRS tax forms (see the variants section) used in the United States to prepare and file an information return to report various types of income other than wages, salaries, and tips (for which Form W-2 is used instead). The term information return is used in contrast to the term tax return although the latter term is sometimes used colloquially to describe both kinds of returns.';
//     } else if (formType === 'w9'){
//       answer = 'Form W-9 (officially, the "Request for Taxpayer Identification Number and Certification")[1] is used in the United States income tax system by a third party who must file an information return with the Internal Revenue Service (IRS).[2] It requests the name, address, and taxpayer identification';
//     } else {
//       answer = 'Sorry, we are not aware of that for now!'
//     }
//     return resolve(`Okay, so ${answer}`);
//   });
// }

app.intent(NAME_ACTION, (conv, params) => {
  console.log('conv', conv);
  console.log('params', params);
  const formType = params.formtype;
  if (!formType) conv.close('No form type detected!');
  if (formType == '1040') {
    answer = 'Form 1040 (officially, the "U.S. Individual Income Tax Return") is one of three IRS Tax forms used for personal (individual) federal income tax filed with internal revenue service';
  } else if (formType == '1099') {
    answer = 'Form 1099 is one of several IRS tax forms (see the variants section) used in the United States to prepare and file an information return to report various types of income other than wages, salaries, and tips (for which Form W-2 is used instead). The term information return is used in contrast to the term tax return although the latter term is sometimes used colloquially to describe both kinds of returns.';
  } else if (formType == 'w9'){
    answer = 'Form W-9 (officially, the "Request for Taxpayer Identification Number and Certification")[1] is used in the United States income tax system by a third party who must file an information return with the Internal Revenue Service (IRS).[2] It requests the name, address, and taxpayer identification';
  } else {
    answer = 'Sorry, we are not aware of that for now!'
  }
  conv.close(`Okay, so ${answer}`);
});


exports.intuitHome = functions.https.onRequest(app);
